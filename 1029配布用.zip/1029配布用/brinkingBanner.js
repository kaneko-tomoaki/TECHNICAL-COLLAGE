  document.addEventListener('DOMContentLoaded', () => {
    const img = document.querySelector('.bnr_inner a[href="contact.html"] img');
    // if (!img || !img.animate) return;
    img.addEventListener('mouseenter', () => {
      img.animate(
        [
          { filter: 'brightness(1)' },
          { filter: 'brightness(1.6)' },
          { filter: 'brightness(1)' }
        ],
        { duration: 300, iterations: 2, easing: 'ease-out' }
      );
    });
  });

    document.addEventListener('DOMContentLoaded', () => {
    const img = document.querySelector('.bnr_inner a[href="plan.html"] img');
    // if (!img || !img.animate) return;
    img.addEventListener('mouseenter', () => {
      img.animate(
        [
          { filter: 'brightness(1)' },
          { filter: 'brightness(1.15)' },
          { filter: 'brightness(1)' }
        ],
        { duration: 900, iterations: 2, easing: 'ease-out' }
      );
    });
  });
