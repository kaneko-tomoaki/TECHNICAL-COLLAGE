document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector(".header");
  const drawerToggle = document.querySelector(".drawer_hidden");
  const pageTopButton = document.querySelector("#js-page-top");

  function getNavHeight() {
    return header ? header.offsetHeight : 0;
  }

  function closeDrawer() {
    if (drawerToggle && drawerToggle.checked) {
      drawerToggle.checked = false;
    }
  }

  function smoothScrollTo(position) {
    window.scrollTo({
      top: position,
      behavior: "smooth",
    });
  }

  const anchorLinks = document.querySelectorAll('a[href^="#"]');

  anchorLinks.forEach(function (link) {
    link.addEventListener("click", function (event) {
      const href = link.getAttribute("href");
      const targetElement =
        href === "#" || href === "" ? document.documentElement : document.querySelector(href);

      if (!targetElement) {
        return;
      }

      event.preventDefault();

      const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - getNavHeight();

      smoothScrollTo(targetPosition);
      closeDrawer();
    });
  });

  if (pageTopButton) {
    pageTopButton.addEventListener("click", function (event) {
      event.preventDefault();
      smoothScrollTo(0);
      closeDrawer();
    });
  }

  window.addEventListener("resize", function () {
    if (window.innerWidth > 767) {
      closeDrawer();
    }
  });

  const worksDetailPage = document.body.classList.contains("works-detail-page");

  if (worksDetailPage) {
    const worksBody = document.body;
    const transitionDuration = 400;
    const pageLinks = document.querySelectorAll("a");

    function showWorksPage() {
      worksBody.classList.remove("is-fading-out");
      worksBody.classList.add("is-visible");
    }

    window.addEventListener("load", function () {
      requestAnimationFrame(showWorksPage);
    });

    if (document.readyState === "complete") {
      requestAnimationFrame(showWorksPage);
    }

    window.addEventListener("pageshow", function (event) {
      if (event.persisted) {
        requestAnimationFrame(showWorksPage);
      }
    });

    pageLinks.forEach(function (link) {
      link.addEventListener("click", function (event) {
        if (event.defaultPrevented) {
          return;
        }

        if (
          event.button !== 0 ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey
        ) {
          return;
        }

        const href = link.getAttribute("href") || "";

        if (!href || href.charAt(0) === "#") {
          return;
        }

        if (
          link.target === "_blank" ||
          link.hasAttribute("download") ||
          href.startsWith("mailto:") ||
          href.startsWith("tel:") ||
          href.startsWith("javascript:")
        ) {
          return;
        }

        event.preventDefault();
        worksBody.classList.add("is-fading-out");

        setTimeout(function () {
          window.location.href = href;
        }, transitionDuration);
      });
    });
  }
});
